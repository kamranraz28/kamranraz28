<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        DB::table('products')->insert(
            [
                [
                    'name'=>'OPPO mobile',
                    'price'=>'250',
                    'description'=>'A smartphone with 6gb ram and 128gb rom and much more featurtes',
                    'category'=>'mobile',
                    'gallery'=>'https://tse3.mm.bing.net/th?id=OIP.G7jTQJeHzLKEKUQl0h9JMwHaHa&pid=Api&P=0',
                ],
                [
                    'name'=>'Panasonic TV',
                    'price'=>'300',
                    'description'=>'A smart television with 56 inch display and 8gb graphichs and much more featurtes',
                    'category'=>'tv',
                    'gallery'=>'https://tse1.mm.bing.net/th?id=OIP.Gr8SPVqQpk1ZrJUlgyO_bQHaHa&pid=Api&P=0',
                ],
                [
                    'name'=>'Sony TV',
                    'price'=>'500',
                    'description'=>'A smart television with 60 inch display and 16gb graphics and much more featurtes',
                    'category'=>'tv',
                    'gallery'=>'https://m.xcite.com/media/catalog/product/6/1/61ptuq1nmol._sl1500__result_1_result.jpg',
                ],
                [
                    'name'=>'LG fridge',
                    'price'=>'200',
                    'description'=>'A refrigerator with much more featurtes',
                    'category'=>'fridge',
                    'gallery'=>'https://tse2.mm.bing.net/th?id=OIP.yTTDo3dZzkTeF0P65-yJsAHaJZ&pid=Api&P=0',
                ]
            ]
            );
    }
}
